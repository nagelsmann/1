#ifndef _SMOKE_LED_
#define _SMOKE_LED_

//初始化烟雾探测模块的LED报警灯
hi_void smoke_led_init(void);

//控制烟雾探测模块的LED报警灯，1:点亮; 2:熄灭
hi_void smoke_led_ctrl(unsigned int state);

#endif

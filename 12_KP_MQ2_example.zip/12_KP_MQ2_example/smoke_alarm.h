#ifndef _SMOKE_ALARM_
#define _SMOKE_ALARM_

//初始化烟雾探测模块的蜂鸣器
hi_void smoke_alarm_init(hi_void);

//使能蜂鸣器发声
hi_void smoke_alarm_start(void);

//停止蜂鸣器发声
hi_void smoke_alarm_stop(void);

#endif

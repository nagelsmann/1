#include <stdio.h>
#include "smoke_adc.h"

#define ADC_TEST_LENGTH  128

hi_u16 s_adc_buf[ADC_TEST_LENGTH] = { 0 };

//将内部值转换成电压值，取多次采样的最高电压值
float smoke_convert_to_voltage(hi_u32 data_len)
{
    hi_u32 i;
    float vlt_max = 0;
    hi_u16 vlt;
    for (i = 0; i < data_len; i++) {
        vlt = s_adc_buf[i];
        float voltage = (float)vlt * 1.8 * 4 / 4096.0;  /* vlt * 1.8 * 4 / 4096.0: Convert code into voltage */
        vlt_max = (voltage > vlt_max) ? voltage : vlt_max;
    }

    return vlt_max;
}

//采集烟雾传感器的电压，并返回本阶段采到的最大值
float smoke_adc_gather(hi_void)
{
    hi_u32 ret, i;
    hi_u16 data;  /* 10 */
    float vlt_max = 0;

    memset_s(s_adc_buf, sizeof(s_adc_buf), 0x0, sizeof(s_adc_buf));
    for (hi_u8 em = 0; em < HI_ADC_EQU_MODEL_BUTT; em++) {
        for (i = 0; i < ADC_TEST_LENGTH; i++) {
            //烟雾传感器连接的是ADC 3号通道
	        ret = hi_adc_read(HI_ADC_CHANNEL_3, &data, (hi_adc_equ_model_sel)em, HI_ADC_CUR_BAIS_DEFAULT, 0);
            if (ret != HI_ERR_SUCCESS) {
                printf("ADC Read Fail\n");
                return;
            }
            s_adc_buf[i] = data;
        }
        float voltage = smoke_convert_to_voltage(ADC_TEST_LENGTH);
	    vlt_max = (voltage > vlt_max) ? voltage : vlt_max;
    }
    return vlt_max;

}

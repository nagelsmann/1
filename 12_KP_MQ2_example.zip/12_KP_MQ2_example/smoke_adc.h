#ifndef __SMOKE_ADC_H__
#define __SMOKE_ADC_H__

#include "hi_adc.h"
//采集烟雾探测器对应的电压值
extern float smoke_adc_gather(hi_void);

#endif

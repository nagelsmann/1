# 启航KP_IOT烟雾传感器模块
本示例将演示如何利用启航KP_IOT主控板控制烟雾传感器模块开发样例。

## 模块介绍
烟雾检测模块包括一个MQ-2传感器和一个蜂鸣器、led灯，当模块检测到烟雾浓度超标时，蜂鸣器会报警。MQ-2型烟雾传感器属于二氧化锡半导体气敏材料，属于表面离子式N型半导体。处于200~300摄氏度时，二氧化锡吸附空气中的氧，形成氧的负离子吸附，使半导体中的电子密度减少，从而使其电阻值增加。当与烟雾接触时，如果晶粒间界处的势垒收到烟雾的调至而变化，就会引起表面导电率的变化。利用这一点就可以获得这种烟雾存在的信息，烟雾的浓度越大，导电率越大，输出电阻越低，则输出的模拟信号就越大。我们通过ADC采集MQ-2接入引脚的信号，当引脚电压高于2.5v时输出pwm波驱动蜂鸣器报警，led灯点亮。

## 主要试验步骤

知道模块的工作原理之后开始完成程序的编写程序，我们用到了ADC采集需要知道我们采集的引脚对应的通道，这个可以查找规格书了解。

从原理图中可以看到烟雾检测传感器接在GPIO_07，蜂鸣器接在GPIO_02，LED灯接在GPIO_05。

* 步骤1 完成蜂鸣器接入引脚的复用，蜂鸣器是通过pwm控制的，首先要先对pwm进行复用。因为pwm是属于功能性引脚，所以复用是在app/wifiiot_app/init/app_io_init.c中，将io2复用成pwm输出。

```c
// 蜂鸣器引脚初始化
hi_void smoke_pwm_init(hi_void)
{
    int ret = -1;
    ret = hi_pwm_deinit(HI_PWM_PORT_PWM2);          //去初始化pwm2
    if(ret != 0){ 
        printf("hi_pwm_deinit failed :%#x \r\n",ret); 
    }

    ret = hi_pwm_init(HI_PWM_PORT_PWM2);            //初始化pwm2
    if(ret != 0){ 
        printf("hi_pwm_init failed :%#x \r\n",ret);     
    }
    ret = hi_pwm_set_clock(PWM_CLK_160M);
    if(ret != 0){ 
        printf("hi_pwm_set_clock failed ret : %#x \r\n",ret); 
    }
}
```

* 步骤2 led的控制是一个普通的gpio，所以直接设置gpio的功能和方向即可。在smoke_module/smoke_module.c中声明gpio的初始化。
```c
// gpio5烟雾报警灯
hi_void smoke_gpio_io_init(void)
{
    hi_u32 ret;
    ret = hi_io_set_func(HI_IO_NAME_GPIO_5, HI_IO_FUNC_GPIO_5_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_io_set_func ret:%d\r\n", ret);
        return;
    }
    printf("----- gpio5 smoke set func success-----\r\n");

    ret = hi_gpio_set_dir(HI_GPIO_IDX_5, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_gpio_set_dir1 ret:%d\r\n", ret);
        return;
    }
    printf("----- gpio set dir success! -----\r\n");   
}
```

* 步骤3 led灯的控制，通过参数state来控制，state为1时io5输出高电平，state为0时io5输出低电平。
```c
// LED灯状态判断
hi_void smoke_led_ctrl(unsigned int state)
{  
    if(state == 1){
        printf("----- smoke alarm led turn on -----\r\n");
        hi_gpio_set_ouput_val(HI_GPIO_IDX_5,HI_GPIO_VALUE1);
    }else{
        printf("----- smoke alarm led turn off -----\r\n");
        hi_gpio_set_ouput_val(HI_GPIO_IDX_5,HI_GPIO_VALUE0);
    }
}
```

* 步骤4 烟雾检测传感器使用ADC采集引脚电压，我们创建一个新的文件smoke_adc.c来完成ADC采集这一部分的功能。
```c
//烟雾检测传感器使用ADC采集引脚电压
hi_void smoke_adc_gather(hi_void)
{
    hi_u32 ret, i;
    hi_u16 data;  /* 10 */
    printf("ADC Test Start\n");

    memset_s(s_adc_buf, sizeof(s_adc_buf), 0x0, sizeof(s_adc_buf));
    for (hi_u8 em = 0; em < HI_ADC_EQU_MODEL_BUTT; em++) {
        for (i = 0; i < ADC_TEST_LENGTH; i++) {
            ////采集ADC3电压值
            ret = hi_adc_read(HI_ADC_CHANNEL_3, &data, (hi_adc_equ_model_sel)em, HI_ADC_CUR_BAIS_DEFAULT, 0);
            if (ret != HI_ERR_SUCCESS) {
            printf("ADC Read Fail\n");
                return;
            }
            s_adc_buf[i] = data;
        }
        smoke_convert_to_voltage(ADC_TEST_LENGTH);//将采集的数据转换成可视的电压数值 
    }
    printf("ADC Test Average Mode End\n");
}
```

* 步骤5 ADC采集的数据并不是我们所见的3.3v这样的数值，我们需要将采集到的数据转换成可视的数值。
```c
hi_void smoke_convert_to_voltage(hi_u32 data_len)
{
    hi_u32 i;
    float vlt_max = 0;
    float vlt_min = VLT_MIN;
    hi_u16 vlt;
    for (i = 0; i < data_len; i++) {
        //我们采集的数据都存储在该数组中
        vlt = s_adc_buf[i];
        //数据转换公式
        float voltage = (float)vlt * 1.8 * 4 / 4096.0;  /* vlt * 1.8 * 4 / 4096.0: Convert code into voltage */
        vlt_max = (voltage > vlt_max) ? voltage : vlt_max;
    }
    printf("vlt_max:%.3f \n", vlt_max);
    //当采集电压大于2.5时，说明检测到烟雾超标，pwm输出50占空比的信号，蜂鸣器报警，led点亮
    if(vlt_max > 2.5){
        printf("smoke alarm \r\n");
        smoke_pwm_start(50);
    }else{
        smoke_pwm_start(0);
    }
}
```

* 步骤6  功能都完成之后在smoke_demo()中的调用这些功能来实现人体检测的功能，具体调用位置如下:

```c
 hi_void smoke_adc_demo(hi_void)
{   
    int ret;

    smoke_gpio_io_init();
    smoke_pwm_init();
    
    ret = hi_task_create(&g_MonitorTask, // task标识 //
        &MonitorTaskAttr,
        MonitorTask_smoke, // task处理函数 //
        NULL); // task处理函数参数 //
}
```
* 步骤7  修改 device/board/isoftstone/qihang/app/ `路径下 BUILD.gn 文件，指定 `MQ2_test` 参与编译。

```c
 "12_KP_MQ2_example:MQ2_test",
```

### 运行结果

示例代码编译烧录代码后，按下开发板的RESET按键，通过串口助手查看日志。观察串口输出的电压值，然后适当人为制造点烟雾( **注意安全** )，
观察电压值的变化，当电压值超过代码中记录的阈值时，蜂鸣器报警

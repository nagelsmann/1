#include "hi_io.h"
#include "hi_pwm.h"

/*
 * 使用PWM驱动蜂鸣器发声，可以通过占空比来调整音量
 * 目前暂时固化成50%占空比
 */
#define DUTY 50
// PWM的工作时钟频率
#define PWM_CLK_FREQ 160000000

//分频倍数
#define freq 2442

//初始化蜂鸣器
hi_void smoke_alarm_init(hi_void)
{
    int ret = -1;
    //蜂鸣器接在GPIO2引脚，使用其PWM功能，可以控制音量大小
    ret = hi_io_set_func(HI_IO_NAME_GPIO_2, HI_IO_FUNC_GPIO_2_PWM2_OUT);
    if(ret != 0) {
        printf("\r\n");
    }
    //重新初始化PWM2通道
    ret = hi_pwm_deinit(HI_PWM_PORT_PWM2);
    if(ret != 0){
        printf("hi_pwm_deinit failed :%#x \r\n",ret);
    }

    ret = hi_pwm_init(HI_PWM_PORT_PWM2);
    if(ret != 0){
        printf("hi_pwm_init failed :%#x \r\n",ret);
    }

    ret = hi_pwm_set_clock(PWM_CLK_160M);
    if(ret != 0){
        printf("hi_pwm_set_clock failed ret : %#x \r\n",ret);
    }
}


//使能蜂鸣器发声
hi_void smoke_alarm_start(void)
{
	int ret = hi_pwm_start(HI_PWM_PORT_PWM2, DUTY*(PWM_CLK_FREQ/freq)/100, PWM_CLK_FREQ/freq); 
    if (ret != 0) {  
        printf("hi_pwm_start failed ret : %#x \r\n",ret); 
	}
}

//停止蜂鸣器发声
hi_void smoke_alarm_stop(void)
{
	int ret = hi_pwm_stop(HI_PWM_PORT_PWM2);  
	if ( ret != 0 ) {          
        printf("hi_pwm_stop failed ret : %#x \r\n",ret);        
    }
}

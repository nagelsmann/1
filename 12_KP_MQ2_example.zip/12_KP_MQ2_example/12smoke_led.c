#include "hi_gpio.h"
#include "hi_io.h"	

// 烟雾探测器的LED报警灯连接芯片的GPIO5引脚
hi_void smoke_led_init(void)
{
	hi_u32 ret;

	//此引脚开启常规GPIO功能
	ret = hi_io_set_func(HI_IO_NAME_GPIO_5, HI_IO_FUNC_GPIO_5_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_io_set_func ret:%d\r\n", ret);
        return;
    }

	//此引脚设置成输出有效，通过输出高电平点亮LED灯
    ret = hi_gpio_set_dir(HI_GPIO_IDX_5, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_gpio_set_dir ret:%d\r\n", ret);
        return;
	}	
	
	printf("----- smoke alarm led init success -----\r\n");
}

//点亮或熄灭LED灯
hi_void smoke_led_ctrl(unsigned int state)
{
	if (state == 1) {
		printf("----- smoke alarm led turn on -----\r\n");
		hi_gpio_set_ouput_val(HI_GPIO_IDX_5,HI_GPIO_VALUE1);
	} else {
	    printf("----- smoke alarm led turn off -----\r\n");
	    hi_gpio_set_ouput_val(HI_GPIO_IDX_5,HI_GPIO_VALUE0);
	}
}

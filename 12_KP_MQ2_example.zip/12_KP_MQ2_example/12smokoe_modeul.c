#include <stdio.h>
#include "smoke_adc.h"
#include "smoke_led.h"
#include "smoke_alarm.h"
#include "hi_task.h"
#include "ohos_init.h"


static unsigned int g_MonitorTask;
static const hi_task_attr MonitorTaskAttr = {
    .task_prio = 20,
    .stack_size = 4096,
    .task_name = "smoke_alarm_task",
};

void *MonitorTask_smoke(void * para) /* smoke task处理函数 */
{
    float vlt = 0;
    static int smoke = 0;
    while(1){
        vlt = smoke_adc_gather();
	    printf("vlotage is %.3f\r\n", vlt);
	    //为了实验安全起见，建议此值不要设置过高
	    //可以比正常环境略高即可，即低浓度烟雾也可以触发报警
	    if (vlt > 0.4)
	    {
		    if(smoke == 0)
		    {
			    printf("start \r\n");
			    smoke = 1;
			    smoke_led_ctrl(1);
			    smoke_alarm_start();
		    }
	    } else {
		    if(smoke == 1)
		    {
			    printf("stop \r\n");
			    smoke = 0;
			    smoke_led_ctrl(0);
			    smoke_alarm_stop();
		    }
	    }

	    //控制检测频率，目前暂定3秒一次
	    sleep(3);
    }
    return NULL;
}

 
hi_void smoke_adc_demo(hi_void)
{   
    int ret;

    smoke_led_init();
    smoke_alarm_init();
    
    ret = hi_task_create(&g_MonitorTask, // task标识 //
        &MonitorTaskAttr,
        MonitorTask_smoke, // task处理函数 //
        NULL); // task处理函数参数 //
}

APP_FEATURE_INIT(smoke_adc_demo);
